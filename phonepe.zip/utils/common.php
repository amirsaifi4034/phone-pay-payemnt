<?php 

function getTransactionId() {
    
    return rand(111111111,99999999);

}


?>